//
//  ResultadoViewController.m
//  Tarea1_Abis
//
//  Created by Abismey Tatiana Córdoba Valverde on 6/11/16.
//  Copyright © 2016 Abismey Tatiana Córdoba Valverde. All rights reserved.
//

#import "ResultadoViewController.h"


@interface ResultadoViewController ()
@property (weak, nonatomic) IBOutlet UILabel *resultadoLabel;

@end

@implementation ResultadoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.resultadoLabel.text= [NSString stringWithFormat:@"El Resultado es: %@", self.operacionResultado];
    
    // Do any additional setup after loading the view.
}
/*
- (void)viewDidLoad {
    [super viewDidLoad];
    self.resultadoLabel.text = [ NSString stringWithFormat:@"El resultado de la Operacion es: %@", [self.r personName uppercaseString]];
    
 
 - (void)viewDidLoad {
 [super viewDidLoad];
 
    // Do any additional setup after loading the view.
}
*/
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
