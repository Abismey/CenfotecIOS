//
//  ViewController.m
//  Tarea1_Abis
//
//  Created by Abismey Tatiana Córdoba Valverde on 6/11/16.
//  Copyright © 2016 Abismey Tatiana Córdoba Valverde. All rights reserved.
//

#import "ViewController.h"
#import "ResultadoViewController.h"


@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *dato1;
@property (weak, nonatomic) IBOutlet UITextField *dato2;
@property (weak, nonatomic) IBOutlet UITextField *resultadoTextField;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
       NSLog(@"OPERACIONES");
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    NSCharacterSet *nonNumberSet = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
    
    if ([string rangeOfCharacterFromSet:nonNumberSet].location != NSNotFound)
    {
        return NO;
    }
    return YES;
}

- (IBAction)botonSumar:(UIButton *)sender {
    NSLog (@"PRESIONO EL BOTON SUMAR");
    
    NSInteger resultado=[self.dato1.text intValue] + [self.dato2.text intValue];
    _resultadoTextField.text=[NSString stringWithFormat:@"%ld",resultado];

/*
    ResultadoViewController *nextViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ResultadoViewController"];
    nextViewController.operacionResultado = self.resultadoTextField.text;
    [self.navigationController pushViewController:nextViewController animated:YES];
*/
    
}

- (IBAction)botonRestar:(UIButton *)sender {
     NSLog (@"PRESIONO EL BOTON RESTAR");
    
    NSInteger resultado=[self.dato1.text intValue] - [self.dato2.text intValue];
    _resultadoTextField.text=[NSString stringWithFormat:@"%ld",resultado];
    
/*
    ResultadoViewController *nextViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ResultadoViewController"];
    nextViewController.operacionResultado = self.resultadoTextField.text;
    [self.navigationController pushViewController:nextViewController animated:YES];
*/
}

- (IBAction)botonMultiplicar:(UIButton *)sender {
     NSLog (@"PRESIONO EL BOTON MULTIPLICAR");
 /*   ResultadoViewController *nextViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ResultadoViewController"];
     nextViewController.operacionResultado = self.resultadoTextField.text;
    [self.navigationController pushViewController:nextViewController animated:YES];
*/
    NSInteger resultado=[self.dato1.text intValue] * [self.dato2.text intValue];
    _resultadoTextField.text=[NSString stringWithFormat:@"%ld",resultado];
    
}
- (IBAction)botonDividir:(UIButton *)sender {
     NSLog (@"PRESIONO EL BOTON DIVIDIR");
 
    if (_dato2.text != 0)
 {
    NSInteger resultado=[self.dato1.text intValue] / [self.dato2.text intValue];
    _resultadoTextField.text=[NSString stringWithFormat:@"%ld",resultado];
 }
     else {
         NSLog(@"No se puede realizar una división entre CERO");
     }
    /*   ResultadoViewController *nextViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ResultadoViewController"];
     nextViewController.operacionResultado = self.resultadoTextField.text;
     [self.navigationController pushViewController:nextViewController animated:YES];
     */
}
@end
