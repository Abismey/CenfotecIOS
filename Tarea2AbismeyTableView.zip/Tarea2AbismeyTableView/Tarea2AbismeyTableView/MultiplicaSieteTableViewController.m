//
//  MultiplicaSieteTableViewController.m
//  Tarea2AbismeyTableView
//
//  Created by Abismey Tatiana Córdoba Valverde on 11/11/16.
//  Copyright © 2016 Abismey Tatiana Córdoba Valverde. All rights reserved.
//

#import "MultiplicaSieteTableViewController.h"

#define MULTIPLICADOR_KEY @"multiplicador"
#define RESULTADO_KEY @"resultado"

@interface MultiplicaSieteTableViewController ()
@property(nonatomic,strong) NSArray *multiplicarArray;
@end

@implementation MultiplicaSieteTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createDictonary];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

-(void)createDictonary{
    NSDictionary *firstDictionary = @{MULTIPLICADOR_KEY:@"7x1 = ",
                                      RESULTADO_KEY:@"7"};
    NSDictionary *secondDictionary = @{MULTIPLICADOR_KEY:@"7x2 = ",
                                       RESULTADO_KEY:@"14"};
    NSDictionary *thirdDictionary = @{MULTIPLICADOR_KEY:@"7x3 = ",
                                      RESULTADO_KEY:@"21"};
    NSDictionary *fourthDictionary = @{MULTIPLICADOR_KEY:@"7x4 = ",
                                       RESULTADO_KEY:@"28"};
    NSDictionary *fifthDictionary = @{MULTIPLICADOR_KEY:@"7x5 = ",
                                      RESULTADO_KEY:@"35"};
    NSDictionary *sixthDictionary = @{MULTIPLICADOR_KEY:@"7x6 = ",
                                       RESULTADO_KEY:@"42"};
    NSDictionary *seventhDictionary = @{MULTIPLICADOR_KEY:@"7x7 = ",
                                      RESULTADO_KEY:@"49"};
    NSDictionary *eighthDictionary = @{MULTIPLICADOR_KEY:@"7x8 = ",
                                       RESULTADO_KEY:@"56"};
    NSDictionary *ninthDictionary = @{MULTIPLICADOR_KEY:@"7x9 = ",
                                      RESULTADO_KEY:@"63"};
    NSDictionary *tenthDictionary = @{MULTIPLICADOR_KEY:@"7x10 = ",
                                       RESULTADO_KEY:@"70"};
    NSDictionary *eleventhDictionary = @{MULTIPLICADOR_KEY:@"7x11 = ",
                                      RESULTADO_KEY:@"77"};
    NSDictionary *twelfthDictionary = @{MULTIPLICADOR_KEY:@"7x12 = ",
                                       RESULTADO_KEY:@"84"};
    NSDictionary *thirteenthDictionary = @{MULTIPLICADOR_KEY:@"7x13 = ",
                                      RESULTADO_KEY:@"91"};
    NSDictionary *fourteenthDictionary = @{MULTIPLICADOR_KEY:@"7x14 = ",
                                       RESULTADO_KEY:@"98"};
    NSDictionary *fifteenthDictionary = @{MULTIPLICADOR_KEY:@"7x15 = ",
                                      RESULTADO_KEY:@"105"};
    
    
    self.multiplicarArray = [[NSArray alloc] initWithObjects:firstDictionary,secondDictionary,
        thirdDictionary,fourthDictionary,fifthDictionary,sixthDictionary,seventhDictionary,eighthDictionary,ninthDictionary,tenthDictionary,eleventhDictionary,twelfthDictionary,thirteenthDictionary,fourteenthDictionary,fifteenthDictionary,nil];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

    
#pragma mark - Table view data source
/*
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
#warning Incomplete implementation, return the number of sections
    return 0;
}
*/
    
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.multiplicarArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    
    // Configure the cell...
    NSDictionary *currentMultiplica = self.multiplicarArray[indexPath.row];
    cell.textLabel.text = [currentMultiplica valueForKey:MULTIPLICADOR_KEY];
    
    if (indexPath.row % 2==0){
        cell.detailTextLabel.text = [currentMultiplica valueForKey:RESULTADO_KEY];
    
    }
    else {
        cell.detailTextLabel.text = @"";
    }
    
    cell.detailTextLabel.text = [currentMultiplica valueForKey:RESULTADO_KEY];
    
    return cell;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
