//
//  MultiplicaSieteTableViewController.h
//  Tarea2AbismeyTableView
//
//  Created by Abismey Tatiana Córdoba Valverde on 11/11/16.
//  Copyright © 2016 Abismey Tatiana Córdoba Valverde. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MultiplicaSieteTableViewController : UITableViewController

@end
