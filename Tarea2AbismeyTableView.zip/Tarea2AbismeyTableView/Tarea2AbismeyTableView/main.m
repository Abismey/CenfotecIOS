//
//  main.m
//  Tarea2AbismeyTableView
//
//  Created by Abismey Tatiana Córdoba Valverde on 11/11/16.
//  Copyright © 2016 Abismey Tatiana Córdoba Valverde. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
