//
//  ColorNumbersViewController.m
//  Quiz4AbismeyIOS
//
//  Created by Estudiantes on 19/11/16.
//  Copyright © 2016 Estudiantes. All rights reserved.
//

#import "ColorNumbersViewController.h"
#import "Numeros.h"

@interface ColorNumbersViewController ()
@property (weak, nonatomic) IBOutlet UITableView *TableView;
@property (nonatomic, strong) NSArray *numeroArray;


@end

@implementation ColorNumbersViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

-(void)initializeNumeroArray{
    NSMutableArray *numeroArray = [NSMutableArray new];
    for (int index = 1; index<=5000; index++) {
        Numeros *newNumeros = [[Numeros alloc] initWithName:[NSString stringWithFormat:@"%d",index];
        [numeroArray addObject:newNumeros];
    }
    self.numeroArray = [[NSArray alloc] initWithArray:numeroArray];
}
           
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma -mark TABLE VIEW METHODS

-(NSInteger)TableView:(UITableView *)TableView numberOfRowsInSection:(NSInteger)section {
    return 0;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 160;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
  NumTableViewCell *cell = [TableView dequeueReusableCellWithIdentifier:CUSTOM_CELL_IDENTIFIER];
   Numeros *numeroToShow = self.numeroArray[indexPath.row];
    [cell setupCellWithFibo:numeroToShow];
    return cell;
}




/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
