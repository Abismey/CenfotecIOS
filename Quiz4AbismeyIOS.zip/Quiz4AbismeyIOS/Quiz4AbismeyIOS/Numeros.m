//
//  Numeros.m
//  Quiz4AbismeyIOS
//
//  Created by Estudiantes on 19/11/16.
//  Copyright © 2016 Estudiantes. All rights reserved.
//

#import "Numeros.h"

@interface Numeros()
@property(nonatomic, strong) NSString *numero;
@end


@implementation Numeros

-(id)initWithName:(NSString*)numero
{
    if (self = [super init]) {
        _numero = numero;
        
    }
    return self;
    
}

@end
