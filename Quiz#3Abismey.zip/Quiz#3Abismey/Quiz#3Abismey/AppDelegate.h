//
//  AppDelegate.h
//  Quiz#3Abismey
//
//  Created by Estudiantes on 12/11/16.
//  Copyright © 2016 Estudiantes. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

