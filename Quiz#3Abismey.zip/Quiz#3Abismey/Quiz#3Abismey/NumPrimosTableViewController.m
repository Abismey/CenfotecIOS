//
//  NumPrimosTableViewController.m
//  Quiz#3Abismey
//
//  Created by Estudiantes on 12/11/16.
//  Copyright © 2016 Estudiantes. All rights reserved.
//

#import "NumPrimosTableViewController.h"
#define NUMERO_KEY @"numero"
#define RESULTADOPRIMO_KEY @"resultadoPrimo"

@interface NumPrimosTableViewController ()
@property(nonatomic,strong) NSArray *primoArray;
@end

@implementation NumPrimosTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createDictonary];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

-(void)createDictonary{
    NSDictionary *firstDictionary = @{NUMERO_KEY:@"NUMERO_KEY",
                    RESULTADOPRIMO_KEY:@"RESULTADOPRIMO_KEY"};
    

    self.primoArray = [[NSArray alloc] initWithObjects:firstDictionary,nil];
 }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    //#warning Incomplete implementation, return the number of rows
    return self.primoArray.count;
}

    - (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
        
        NSDictionary *currentPrimo = self.primoArray[indexPath.row];
        cell.textLabel.text = [currentPrimo valueForKey:NUMERO_KEY];
        
        //si quiero que me pinte las celdas pares, con el else limpio para que no me pinte las impares
        if (indexPath.row % 2==0){
            {
                NSInteger primoArray[1000];
                NSInteger z,x,num=1,add=0;
                for(x=0;x<1000;x++)
                {
                    primoArray[x]=num++;
                }
                for(x=0;x<1000;x++)
                {
                    for(z=1;z<=x;z++)
                    {
                        if(x%z==0)add++;
                    }
                    if(add==2)
                    {
                        cont<<primoArray[x];
                    }
            cell.detailTextLabel.text= [currentPrimo valueForKey:RESULTADOPRIMO_KEY];
            
        
        else {
            cell.detailTextLabel.text = @"";
        }
        
        cell.detailTextLabel.text = [currentPrimo valueForKey:RESULTADOPRIMO_KEY];
        return cell;
    }



    
    
/*

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
#warning Incomplete implementation, return the number of sections
    return 0;
}
*/
/*- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
#warning Incomplete implementation, return the number of rows
    return 0;
}
*/
/*
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:<#@"reuseIdentifier"#> forIndexPath:indexPath];
    
    // Configure the cell...
    
    return cell;
}
*/

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
